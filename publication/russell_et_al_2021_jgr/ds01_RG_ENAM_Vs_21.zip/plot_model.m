clear; close all;

infile = './ds01_RG_ENAM_Vs_21.txt';

%      Lat             Lon      Depth (km)        Vs (m/s)   Std. Vs (m/s)
T = readtable(infile);
T.Properties.VariableNames = {'lat', 'lon', 'z', 'vs', 'vs_std'}; % names of columns

lat = unique(T.lat);
lon = unique(T.lon);
z = unique(T.z);

[lon_mesh,lat_mesh, z_mesh] = meshgrid(lon,lat,z);

%% Build up Vs and Vs_std mesh
vs_mesh = nan(size(z_mesh));
vs_std_mesh = nan(size(z_mesh));
for ilat = 1:length(lat)
    for ilon = 1:length(lon)
        ind = find(T.lat==lat(ilat) & T.lon==lon(ilon));
        vs_mesh(ilat,ilon,:) = T.vs(ind);
        vs_std_mesh(ilat,ilon,:) = T.vs_std(ind);
    end
end

%% Plot

% Take horizontal slice
zkm_slice = 30;

[~,Iz] = min(abs(zkm_slice-z));

figure(1); clf;
subplot(1,2,1); box on; hold on;
surface(lon_mesh(:,:,Iz),lat_mesh(:,:,Iz),zeros(size(z_mesh(:,:,Iz))),vs_mesh(:,:,Iz),'EdgeColor','none','FaceColor','interp');
cb = colorbar;
ylabel(cb,'Vs (km/s)');
colormap(flip(parula));

subplot(1,2,2); box on; hold on;
surface(lon_mesh(:,:,Iz),lat_mesh(:,:,Iz),zeros(size(z_mesh(:,:,Iz))),vs_std_mesh(:,:,Iz),'EdgeColor','none','FaceColor','interp');
cb = colorbar;
ylabel(cb,'Vs std. (km/s)');
colormap(flip(parula));



